
package ro.uvt.dp.strategy;

public interface AlignStrategy {
    String render(String text, int width);
}
